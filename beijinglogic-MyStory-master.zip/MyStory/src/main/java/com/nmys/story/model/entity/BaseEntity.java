package com.nmys.story.model.entity;

import java.io.Serializable;

/**
 * description
 *
 * @author 70KG
 * @date 2018/8/24
 */
public class BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

}
