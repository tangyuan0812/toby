package com.nmys.story.model.entity;

public class MetasEx extends Metas {

    private int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

}
