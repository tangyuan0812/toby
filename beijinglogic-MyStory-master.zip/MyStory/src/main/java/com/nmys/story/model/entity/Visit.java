package com.nmys.story.model.entity;

import lombok.Data;

@Data
public class Visit {

    private Integer id;

    private Integer count;

    private Integer modifyTime;

}
