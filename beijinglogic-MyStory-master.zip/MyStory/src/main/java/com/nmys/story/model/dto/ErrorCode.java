package com.nmys.story.model.dto;

/**
 * 错误提示
 * Created by 70kg
 */
public interface ErrorCode {

    /**
     * 非法请求
     */
    String BAD_REQUEST = "BAD REQUEST";

}