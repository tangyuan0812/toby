package com.nmys.story.test_upload;

import com.nmys.story.utils.UploadUtil;
import org.junit.Test;

public class Test01 {


    public static void main(String[] args){
        System.out.println(upload());
//        String url = UploadUtil.getURL("FqVLt8NzzFDyoxQktRyTsRAoT-Q9");
//        System.out.println("-----"+url);

    }

    public static String upload(){
        String upload = UploadUtil.upload("E:\\MyBlog\\MyStory\\src\\main\\resources\\static\\user\\img\\logo.png");
        return upload;
    }


}
