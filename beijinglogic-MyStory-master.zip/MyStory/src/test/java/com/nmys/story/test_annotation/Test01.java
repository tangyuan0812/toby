package com.nmys.story.test_annotation;

public class Test01 {

    public static void main(String[] args){

    }

    @LogAnnotation("123456789")
    public static void m1(){

    }

}
